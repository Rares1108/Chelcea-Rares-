<?php
header("Content-Type: application/json");
require_once("../db.php");

$method = $_SERVER["REQUEST_METHOD"];

if ($method === "GET") {
    // Afișare studenți
    $result = $conn->query("SELECT * FROM students");
    $students = [];

    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }

    echo json_encode($students);
}

if ($method === "POST") {
    // Citim datele trimise prin fetch
    $data = json_decode(file_get_contents("php://input"), true);

    $nume  = $data["nume"];
    $an    = $data["an"];
    $media = $data["media"];

    $stmt = $conn->prepare("INSERT INTO students (nume, an, media) VALUES (?, ?, ?)");
    $stmt->bind_param("sid", $nume, $an, $media);
    $stmt->execute();

    echo json_encode(["success" => true]);
}
?>
