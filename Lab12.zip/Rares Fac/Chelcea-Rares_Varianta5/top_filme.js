document.addEventListener("DOMContentLoaded", () => {
    const cards = document.querySelectorAll(".card");
    const modal = document.getElementById("movieModal");
    const modalTitle = document.getElementById("modalTitle");
    const modalGenre = document.getElementById("modalGenre");
    const modalYear = document.getElementById("modalYear");
    const modalRating = document.getElementById("modalRating");
    const modalReview = document.getElementById("modalReview");
    const closeBtn = document.querySelector(".close");

    // Informațiile despre filme
    const filmeInfo = {
        "Citizen Kane": {
            descriere: "Un film clasic despre putere și ambiție.",
            recenzie: "★★★★★ 10/10",
            an: 1941,
            rating: "10/10",
            gen: "Clasice"
        },
        "The Godfather": {
            descriere: "Povestea legendară a familiei mafiote Corleone.",
            recenzie: "★★★★★ 10/10",
            an: 1972,
            rating: "10/10",
            gen: "Clasice"
        },
        "Goodfellas": {
            descriere: "Un portret intens al lumii gangsterilor.",
            recenzie: "★★★★★ 9.5/10",
            an: 1990,
            rating: "9.5/10",
            gen: "Clasice"
        },
        "12 Angry Men": {
            descriere: "Drama puternică despre justiție și prejudecăți.",
            recenzie: "★★★★★ 9.5/10",
            an: 1957,
            rating: "9.5/10",
            gen: "Clasice"
        },
        "The Dark Knight": {
            descriere: "Batman vs Joker: lupte morale și tensiune pură.",
            recenzie: "★★★★★ 10/10",
            an: 2008,
            rating: "10/10",
            gen: "Acțiune"
        },
        "Gladiator": {
            descriere: "Epopeea epică a unui general roman.",
            recenzie: "★★★★★ 9.5/10",
            an: 2000,
            rating: "9.5/10",
            gen: "Acțiune"
        },
        "The Matrix": {
            descriere: "Un clasic SF cu lupte spectaculoase și filozofie.",
            recenzie: "★★★★★ 9/10",
            an: 1999,
            rating: "9/10",
            gen: "Acțiune"
        },
        "Casino Royale": {
            descriere: "James Bond revine în stil clasic cu multă tensiune.",
            recenzie: "★★★★★ 9/10",
            an: 2006,
            rating: "9/10",
            gen: "Acțiune"
        },
        "Fight Club": {
            descriere: "Explorarea identității și alienării.",
            recenzie: "★★★★★ 9.5/10",
            an: 1999,
            rating: "9.5/10",
            gen: "Psihologic"
        },
        "Shutter Island": {
            descriere: "Thriller intens cu răsturnări de situație.",
            recenzie: "★★★★★ 9/10",
            an: 2010,
            rating: "9/10",
            gen: "Psihologic"
        },
        "Inception": {
            descriere: "Visuri și realitate se amestecă într-un mod spectaculos.",
            recenzie: "★★★★★ 10/10",
            an: 2010,
            rating: "10/10",
            gen: "Psihologic"
        },
        "Black Swan": {
            descriere: "Obsesiile și presiunile lumii baletului.",
            recenzie: "★★★★★ 9/10",
            an: 2010,
            rating: "9/10",
            gen: "Psihologic"
        },
        "Forrest Gump": {
            descriere: "O viață plină de aventuri și emoții pure.",
            recenzie: "★★★★★ 10/10",
            an: 1994,
            rating: "10/10",
            gen: "Dramă"
        },
        "The Pursuit of Happyness": {
            descriere: "O poveste emoționantă despre speranță și curaj.",
            recenzie: "★★★★★ 9.5/10",
            an: 2006,
            rating: "9.5/10",
            gen: "Dramă"
        },
        "Moonlight": {
            descriere: "Explorarea identității și dragostei într-un context dificil.",
            recenzie: "★★★★★ 9/10",
            an: 2016,
            rating: "9/10",
            gen: "Dramă"
        },
        "Requiem for a Dream": {
            descriere: "O poveste dureroasă despre dependență și pierdere.",
            recenzie: "★★★★★ 9/10",
            an: 2000,
            rating: "9/10",
            gen: "Dramă"
        },
        "LOTR: Return of the King": {
            descriere: "Finalul epic al trilogiei Lord of the Rings.",
            recenzie: "★★★★★ 10/10",
            an: 2003,
            rating: "10/10",
            gen: "SF/Fantezie"
        },
        "Interstellar": {
            descriere: "O odisee spațială emoționantă și vizual spectaculoasă.",
            recenzie: "★★★★★ 10/10",
            an: 2014,
            rating: "10/10",
            gen: "SF/Fantezie"
        },
        "Avatar": {
            descriere: "O aventură vizuală în lumea Pandora.",
            recenzie: "★★★★★ 9/10",
            an: 2009,
            rating: "9/10",
            gen: "SF/Fantezie"
        },
        "Blade Runner 2049": {
            descriere: "O continuare impresionantă a clasicului Blade Runner.",
            recenzie: "★★★★★ 9/10",
            an: 2017,
            rating: "9/10",
            gen: "SF/Fantezie"
        },
        "La La Land": {
            descriere: "O poveste romantică și muzicală plină de energie.",
            recenzie: "★★★★★ 9/10",
            an: 2016,
            rating: "9/10",
            gen: "Muzical"
        },
        "Whiplash": {
            descriere: "Intensitatea muzicii și a relației profesor-elev.",
            recenzie: "★★★★★ 9/10",
            an: 2014,
            rating: "9/10",
            gen: "Muzical"
        },
        "The Greatest Showman": {
            descriere: "Spectacolul continuu al unei povești inspiraționale.",
            recenzie: "★★★★★ 9/10",
            an: 2017,
            rating: "9/10",
            gen: "Muzical"
        },
        "The Notebook": {
            descriere: "O poveste de dragoste clasică și emoționantă.",
            recenzie: "★★★★★ 9/10",
            an: 2004,
            rating: "9/10",
            gen: "Romantic"
        },
        "500 Days of Summer": {
            descriere: "O explorare modernă a iubirii și despărțirilor.",
            recenzie: "★★★★★ 8.5/10",
            an: 2009,
            rating: "8.5/10",
            gen: "Romantic"
        },
        "Call Me by Your Name": {
            descriere: "O poveste sensibilă despre descoperirea iubirii.",
            recenzie: "★★★★★ 9/10",
            an: 2017,
            rating: "9/10",
            gen: "Romantic"
        }
    };

    // Afișează detaliile filmului la click
    cards.forEach(card => {
        card.addEventListener("click", () => {
            const filmName = card.getAttribute("data-title"); // Obținem titlul filmului din atributul data-title
            if (filmeInfo[filmName]) {
                const film = filmeInfo[filmName];
                modalTitle.textContent = filmName;
                modalGenre.textContent = film.gen;
                modalYear.textContent = film.an;
                modalRating.textContent = film.rating;
                modalReview.textContent = film.descriere;
                modal.style.display = "block"; // Deschide modalul
            }
        });
    });

    // Închide modalul
    closeBtn.addEventListener("click", () => {
        modal.style.display = "none";
    });

    // Închide modalul dacă se face click în afara acestuia
    window.addEventListener("click", (e) => {
        if (e.target === modal) {
            modal.style.display = "none";
        }
    });
});
