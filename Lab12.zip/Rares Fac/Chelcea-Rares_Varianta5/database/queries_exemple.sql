-- ==============================================
-- QUERY-URI EXEMPLE PENTRU CINERECENZII
-- ==============================================

-- 1. SELECTARE FILME
-- ==============================================

-- Toate filmele cu rating mediu
SELECT 
    f.id,
    f.titlu,
    f.an_aparitie,
    f.regizor,
    COUNT(r.id) as numar_recenzii,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM filme f
LEFT JOIN recenzii r ON f.id = r.film_id
GROUP BY f.id, f.titlu, f.an_aparitie, f.regizor
ORDER BY rating_mediu DESC;

-- Filme dintr-un gen specific
SELECT 
    f.titlu,
    f.an_aparitie,
    f.regizor,
    GROUP_CONCAT(g.nume SEPARATOR ', ') as genuri
FROM filme f
JOIN filme_genuri fg ON f.id = fg.film_id
JOIN genuri g ON fg.gen_id = g.id
WHERE g.nume = 'SF/Fantezie'
GROUP BY f.id, f.titlu, f.an_aparitie, f.regizor;

-- Top 10 filme după număr de recenzii
SELECT 
    f.titlu,
    f.an_aparitie,
    COUNT(r.id) as numar_recenzii,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM filme f
JOIN recenzii r ON f.id = r.film_id
GROUP BY f.id, f.titlu, f.an_aparitie
ORDER BY numar_recenzii DESC
LIMIT 10;

-- Filme din ultimii 5 ani
SELECT 
    f.titlu,
    f.an_aparitie,
    f.regizor,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM filme f
LEFT JOIN recenzii r ON f.id = r.film_id
WHERE f.an_aparitie >= YEAR(CURDATE()) - 5
GROUP BY f.id, f.titlu, f.an_aparitie, f.regizor
ORDER BY rating_mediu DESC;

-- 2. RECENZII
-- ==============================================

-- Recenzii recente (ultimele 20)
SELECT 
    r.id,
    r.titlu as titlu_recenzie,
    f.titlu as film,
    CONCAT(u.nume, ' ', u.prenume) as autor,
    r.rating,
    r.data_publicare,
    LEFT(r.continut, 100) as preview
FROM recenzii r
JOIN filme f ON r.film_id = f.id
JOIN utilizatori u ON r.utilizator_id = u.id
ORDER BY r.data_publicare DESC
LIMIT 20;

-- Recenzii pentru un film specific (ex: The Dark Knight, id=5)
SELECT 
    r.titlu,
    CONCAT(u.nume, ' ', u.prenume) as autor,
    r.rating,
    r.continut,
    r.likes,
    r.dislikes,
    r.data_publicare
FROM recenzii r
JOIN utilizatori u ON r.utilizator_id = u.id
WHERE r.film_id = 5
ORDER BY r.data_publicare DESC;

-- Recenzii cu cel mai multe like-uri
SELECT 
    r.titlu,
    f.titlu as film,
    CONCAT(u.nume, ' ', u.prenume) as autor,
    r.rating,
    r.likes,
    r.dislikes,
    (r.likes - r.dislikes) as scor_net
FROM recenzii r
JOIN filme f ON r.film_id = f.id
JOIN utilizatori u ON r.utilizator_id = u.id
ORDER BY scor_net DESC
LIMIT 10;

-- Recenzii ale unui utilizator specific
SELECT 
    f.titlu as film,
    r.titlu as titlu_recenzie,
    r.rating,
    r.data_publicare,
    r.likes
FROM recenzii r
JOIN filme f ON r.film_id = f.id
WHERE r.utilizator_id = 1
ORDER BY r.data_publicare DESC;

-- 3. UTILIZATORI
-- ==============================================

-- Utilizatori cu cele mai multe recenzii
SELECT 
    u.id,
    CONCAT(u.nume, ' ', u.prenume) as nume_complet,
    u.email,
    COUNT(r.id) as numar_recenzii,
    ROUND(AVG(r.rating), 1) as rating_mediu_acordat
FROM utilizatori u
LEFT JOIN recenzii r ON u.id = r.utilizator_id
GROUP BY u.id, u.nume, u.prenume, u.email
ORDER BY numar_recenzii DESC;

-- Statistici complete utilizator
SELECT 
    CONCAT(u.nume, ' ', u.prenume) as utilizator,
    u.data_inregistrare,
    COUNT(DISTINCT r.id) as recenzii_scrise,
    COUNT(DISTINCT c.id) as comentarii_scrise,
    COUNT(DISTINCT f.id) as filme_favorite,
    COUNT(DISTINCT w.id) as filme_watchlist
FROM utilizatori u
LEFT JOIN recenzii r ON u.id = r.utilizator_id
LEFT JOIN comentarii c ON u.id = c.utilizator_id
LEFT JOIN favorite f ON u.id = f.utilizator_id
LEFT JOIN watchlist w ON u.id = w.utilizator_id
WHERE u.id = 1
GROUP BY u.id, u.nume, u.prenume, u.data_inregistrare;

-- Utilizatori noi (înregistrați în ultima lună)
SELECT 
    CONCAT(nume, ' ', prenume) as nume_complet,
    email,
    data_inregistrare
FROM utilizatori
WHERE data_inregistrare >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
ORDER BY data_inregistrare DESC;

-- 4. COMENTARII
-- ==============================================

-- Comentarii recente
SELECT 
    c.continut,
    CONCAT(u.nume, ' ', u.prenume) as autor,
    r.titlu as recenzie,
    f.titlu as film,
    c.data_publicare
FROM comentarii c
JOIN utilizatori u ON c.utilizator_id = u.id
JOIN recenzii r ON c.recenzie_id = r.id
JOIN filme f ON r.film_id = f.id
ORDER BY c.data_publicare DESC
LIMIT 20;

-- Comentarii pentru o recenzie specifică
SELECT 
    c.continut,
    CONCAT(u.nume, ' ', u.prenume) as autor,
    c.data_publicare
FROM comentarii c
JOIN utilizatori u ON c.utilizator_id = u.id
WHERE c.recenzie_id = 1
ORDER BY c.data_publicare ASC;

-- 5. FAVORITE ȘI WATCHLIST
-- ==============================================

-- Filme favorite pentru un utilizator
SELECT 
    f.titlu,
    f.an_aparitie,
    f.regizor,
    fav.data_adaugare,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM favorite fav
JOIN filme f ON fav.film_id = f.id
LEFT JOIN recenzii r ON f.id = r.film_id
WHERE fav.utilizator_id = 1
GROUP BY f.id, f.titlu, f.an_aparitie, f.regizor, fav.data_adaugare
ORDER BY fav.data_adaugare DESC;

-- Watchlist pentru un utilizator
SELECT 
    f.titlu,
    f.an_aparitie,
    f.regizor,
    w.data_adaugare,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM watchlist w
JOIN filme f ON w.film_id = f.id
LEFT JOIN recenzii r ON f.id = r.film_id
WHERE w.utilizator_id = 1
GROUP BY f.id, f.titlu, f.an_aparitie, f.regizor, w.data_adaugare
ORDER BY w.data_adaugare DESC;

-- Cele mai adăugate filme la favorite
SELECT 
    f.titlu,
    f.an_aparitie,
    COUNT(fav.id) as numar_favorite,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM filme f
LEFT JOIN favorite fav ON f.id = fav.film_id
LEFT JOIN recenzii r ON f.id = r.film_id
GROUP BY f.id, f.titlu, f.an_aparitie
ORDER BY numar_favorite DESC
LIMIT 10;

-- 6. CĂUTARE ȘI FILTRARE
-- ==============================================

-- Căutare filme după cuvânt cheie
SELECT 
    f.titlu,
    f.an_aparitie,
    f.regizor,
    f.descriere,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM filme f
LEFT JOIN recenzii r ON f.id = r.film_id
WHERE f.titlu LIKE '%dark%'
   OR f.descriere LIKE '%dark%'
   OR f.regizor LIKE '%dark%'
   OR f.actori LIKE '%dark%'
GROUP BY f.id, f.titlu, f.an_aparitie, f.regizor, f.descriere;

-- Filme cu rating peste 9.0
SELECT 
    f.titlu,
    f.an_aparitie,
    ROUND(AVG(r.rating), 1) as rating_mediu,
    COUNT(r.id) as numar_recenzii
FROM filme f
JOIN recenzii r ON f.id = r.film_id
GROUP BY f.id, f.titlu, f.an_aparitie
HAVING rating_mediu >= 9.0
ORDER BY rating_mediu DESC;

-- Filme dintr-un interval de ani
SELECT 
    f.titlu,
    f.an_aparitie,
    f.regizor,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM filme f
LEFT JOIN recenzii r ON f.id = r.film_id
WHERE f.an_aparitie BETWEEN 2010 AND 2020
GROUP BY f.id, f.titlu, f.an_aparitie, f.regizor
ORDER BY rating_mediu DESC;

-- 7. STATISTICI GENERALE
-- ==============================================

-- Statistici generale platformă
SELECT 
    (SELECT COUNT(*) FROM utilizatori) as total_utilizatori,
    (SELECT COUNT(*) FROM filme) as total_filme,
    (SELECT COUNT(*) FROM recenzii) as total_recenzii,
    (SELECT COUNT(*) FROM comentarii) as total_comentarii,
    (SELECT ROUND(AVG(rating), 1) FROM recenzii) as rating_mediu_general;

-- Genuri cele mai populare
SELECT 
    g.nume as gen,
    g.icona,
    COUNT(DISTINCT fg.film_id) as numar_filme,
    COUNT(DISTINCT r.id) as numar_recenzii,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM genuri g
LEFT JOIN filme_genuri fg ON g.id = fg.gen_id
LEFT JOIN recenzii r ON fg.film_id = r.film_id
GROUP BY g.id, g.nume, g.icona
ORDER BY numar_recenzii DESC;

-- Activitate pe lună (ultimele 6 luni)
SELECT 
    DATE_FORMAT(r.data_publicare, '%Y-%m') as luna,
    COUNT(r.id) as recenzii_noi,
    COUNT(DISTINCT r.utilizator_id) as utilizatori_activi
FROM recenzii r
WHERE r.data_publicare >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
GROUP BY luna
ORDER BY luna DESC;

-- Filme fără recenzii
SELECT 
    f.id,
    f.titlu,
    f.an_aparitie,
    f.regizor
FROM filme f
LEFT JOIN recenzii r ON f.id = r.film_id
WHERE r.id IS NULL;

-- 8. RAPOARTE AVANSATE
-- ==============================================

-- Top 5 filme pe fiecare gen
SELECT * FROM (
    SELECT 
        g.nume as gen,
        f.titlu,
        f.an_aparitie,
        ROUND(AVG(r.rating), 1) as rating_mediu,
        COUNT(r.id) as numar_recenzii,
        ROW_NUMBER() OVER (PARTITION BY g.id ORDER BY AVG(r.rating) DESC) as rank_in_gen
    FROM genuri g
    JOIN filme_genuri fg ON g.id = fg.gen_id
    JOIN filme f ON fg.film_id = f.id
    LEFT JOIN recenzii r ON f.id = r.film_id
    GROUP BY g.id, g.nume, f.id, f.titlu, f.an_aparitie
    HAVING numar_recenzii > 0
) ranked
WHERE rank_in_gen <= 5
ORDER BY gen, rank_in_gen;

-- Comparație rating-uri utilizatori vs critici (presupunând că avem un câmp is_critic)
-- Pentru demonstrație, considerăm utilizatorul 1 și 2 ca fiind critici
SELECT 
    f.titlu,
    ROUND(AVG(CASE WHEN r.utilizator_id IN (1,2) THEN r.rating END), 1) as rating_critici,
    ROUND(AVG(CASE WHEN r.utilizator_id NOT IN (1,2) THEN r.rating END), 1) as rating_public,
    COUNT(r.id) as total_recenzii
FROM filme f
LEFT JOIN recenzii r ON f.id = r.film_id
GROUP BY f.id, f.titlu
HAVING total_recenzii >= 3
ORDER BY ABS(rating_critici - rating_public) DESC;

-- Utilizatori cu gusturi similare (bazat pe filme favorite comune)
SELECT 
    u1.id as user1_id,
    CONCAT(u1.nume, ' ', u1.prenume) as user1,
    u2.id as user2_id,
    CONCAT(u2.nume, ' ', u2.prenume) as user2,
    COUNT(*) as filme_favorite_comune
FROM favorite f1
JOIN favorite f2 ON f1.film_id = f2.film_id AND f1.utilizator_id < f2.utilizator_id
JOIN utilizatori u1 ON f1.utilizator_id = u1.id
JOIN utilizatori u2 ON f2.utilizator_id = u2.id
GROUP BY u1.id, u1.nume, u1.prenume, u2.id, u2.nume, u2.prenume
HAVING filme_favorite_comune >= 2
ORDER BY filme_favorite_comune DESC;

-- 9. INSERT, UPDATE, DELETE EXEMPLE
-- ==============================================

-- Adaugă un film nou
INSERT INTO filme (titlu, titlu_original, an_aparitie, durata, descriere, regizor, actori)
VALUES ('Dune', 'Dune', 2021, 155, 'Adaptare după romanul SF clasic.', 'Denis Villeneuve', 'Timothée Chalamet, Zendaya, Rebecca Ferguson');

-- Adaugă o recenzie
INSERT INTO recenzii (film_id, utilizator_id, rating, titlu, continut)
VALUES (27, 1, 9.5, 'Spectacol vizual impresionant', 'Denis Villeneuve reușește să aducă pe ecran universul complex al lui Dune...');

-- Adaugă un comentariu
INSERT INTO comentarii (recenzie_id, utilizator_id, continut)
VALUES (16, 2, 'Complet de acord! Cinematografia este fenomenală!');

-- Adaugă la favorite
INSERT INTO favorite (utilizator_id, film_id)
VALUES (1, 27);

-- Actualizează o recenzie
UPDATE recenzii
SET continut = 'Conținut actualizat...',
    data_editare = CURRENT_TIMESTAMP
WHERE id = 16 AND utilizator_id = 1;

-- Șterge un comentariu
DELETE FROM comentarii
WHERE id = 1 AND utilizator_id = 1;

-- Like la o recenzie
INSERT INTO recenzii_rating (recenzie_id, utilizator_id, tip)
VALUES (1, 3, 'like')
ON DUPLICATE KEY UPDATE tip = 'like';

-- Dislike la o recenzie
INSERT INTO recenzii_rating (recenzie_id, utilizator_id, tip)
VALUES (2, 3, 'dislike')
ON DUPLICATE KEY UPDATE tip = 'dislike';

-- 10. UTILIZARE VIEWS ȘI PROCEDURES
-- ==============================================

-- Folosire view filme_rating
SELECT * FROM filme_rating WHERE rating_mediu >= 9.0;

-- Folosire view top_filme
SELECT * FROM top_filme LIMIT 10;

-- Folosire view utilizatori_activi
SELECT * FROM utilizatori_activi WHERE numar_recenzii > 0;

-- Apelare procedură adaugă recenzie
CALL adauga_recenzie(5, 3, 8.5, 'Bun dar nu perfect', 'The Dark Knight este un film bun dar...');

-- Apelare procedură căutare filme
CALL cauta_filme('Nolan');

-- Apelare procedură statistici utilizator
CALL statistici_utilizator(1);
