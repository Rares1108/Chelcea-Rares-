<?php
require_once 'config.php';

header('Content-Type: application/json');

$searchQuery = $_GET['q'] ?? '';

if (empty($searchQuery)) {
    echo json_encode(['success' => false, 'message' => 'No search query provided']);
    exit;
}

$conn = getDBConnection();

// Search in movies table
$searchTerm = "%{$searchQuery}%";
$stmt = $conn->prepare("
    SELECT 
        f.id,
        f.titlu,
        f.titlu_original,
        f.an_aparitie,
        f.descriere,
        f.regizor,
        f.poster,
        GROUP_CONCAT(g.nume SEPARATOR ', ') as genuri
    FROM filme f
    LEFT JOIN filme_genuri fg ON f.id = fg.film_id
    LEFT JOIN genuri g ON fg.gen_id = g.id
    WHERE f.titlu LIKE ? OR f.titlu_original LIKE ? OR f.regizor LIKE ?
    GROUP BY f.id
    ORDER BY f.titlu
    LIMIT 20
");

$stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
$stmt->execute();
$result = $stmt->get_result();

$movies = [];
while ($row = $result->fetch_assoc()) {
    $movies[] = [
        'id' => $row['id'],
        'title' => $row['titlu'],
        'originalTitle' => $row['titlu_original'],
        'year' => $row['an_aparitie'],
        'description' => $row['descriere'],
        'director' => $row['regizor'],
        'poster' => $row['poster'],
        'genres' => $row['genuri']
    ];
}

$stmt->close();
$conn->close();

echo json_encode([
    'success' => true,
    'count' => count($movies),
    'movies' => $movies
]);
?>
