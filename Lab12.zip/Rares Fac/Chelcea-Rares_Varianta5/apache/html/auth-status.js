// auth-status.js - Script for checking authentication status and displaying user profile
function checkAuthStatus() {
    const user = JSON.parse(localStorage.getItem('user'));
    const authContainer = document.getElementById('auth-status');
    
    if (!authContainer) return;
    
    if (user && user.name) {
        // User is logged in - show profile dropdown
        authContainer.innerHTML = `
            <div class="user-profile-dropdown">
                <button class="user-profile-btn" id="profileBtn">
                    <span class="user-icon">👤</span>
                    <span class="user-name">${user.name}</span>
                    <span class="dropdown-arrow">▼</span>
                </button>
                <div class="dropdown-menu" id="dropdownMenu">
                    <div class="dropdown-item user-info">
                        <strong>${user.name}</strong>
                        <small>${user.email}</small>
                    </div>
                    <hr>
                    <a href="#" class="dropdown-item" id="logoutBtn">
                        <span>🚪</span> Deconectare
                    </a>
                </div>
            </div>
        `;
        
        // Add dropdown toggle functionality
        const profileBtn = document.getElementById('profileBtn');
        const dropdownMenu = document.getElementById('dropdownMenu');
        
        profileBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdownMenu.classList.toggle('show');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', () => {
            dropdownMenu.classList.remove('show');
        });
        
        // Logout functionality
        document.getElementById('logoutBtn').addEventListener('click', (e) => {
            e.preventDefault();
            localStorage.removeItem('user');
            window.location.href = 'login.html';
        });
        
    } else {
        // User is not logged in - show login/register button
        authContainer.innerHTML = `
            <a href="login.html" class="auth-btn">
                <span>🔐</span> Login / Register
            </a>
        `;
    }
}

// Run on page load
document.addEventListener('DOMContentLoaded', checkAuthStatus);
