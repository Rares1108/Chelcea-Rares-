<?php
// Database configuration
define('DB_HOST', 'mysql');
define('DB_USER', 'cine_user');
define('DB_PASS', 'cine_password');
define('DB_NAME', 'cinerecenzii');

// Create database connection
function getDBConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    return $conn;
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
