document.addEventListener("DOMContentLoaded", () => {
    const cards = document.querySelectorAll(".card");
    const modal = document.getElementById("movieModal");
    const modalTitle = document.getElementById("modalTitle");
    const modalGenre = document.getElementById("modalGenre");
    const modalYear = document.getElementById("modalYear");
    const modalRating = document.getElementById("modalRating");
    const modalReview = document.getElementById("modalReview");
    const closeBtn = document.querySelector(".close");
    const reviewsList = document.getElementById("reviewsList");
    const showMoreBtn = document.getElementById("showMoreBtn");

    let currentReviews = [];
    let displayedReviewsCount = 0;

    // Informațiile despre filme
    const filmeInfo = {
        "Citizen Kane": {
            descriere: "Un film clasic despre putere și ambiție.",
            recenzie: "★★★★★ 10/10",
            an: 1941,
            rating: "10/10",
            gen: "Clasice",
            reviews: [
                { user: "Alex M.", rating: 10, text: "Un adevărat capodoperă cinematografică! Tehnica narativă este revoluționară." },
                { user: "Maria P.", rating: 9, text: "Vizual stunning pentru epoca sa. Povestea rămâne actuală." },
                { user: "Dan R.", rating: 10, text: "Citizen Kane redefinește ce înseamnă un film clasic." },
                { user: "Elena V.", rating: 9, text: "Un studiu profund despre ambiție și singurătate." }
            ]
        },
        "The Godfather": {
            descriere: "Povestea legendară a familiei mafiote Corleone.",
            recenzie: "★★★★★ 10/10",
            an: 1972,
            rating: "10/10",
            gen: "Clasice",
            reviews: [
                { user: "Ionuț B.", rating: 10, text: "Cel mai bun film despre mafie. Pacino și Brando sunt fenomenali!" },
                { user: "Cristina D.", rating: 10, text: "Fiecare scenă este memorabilă. Un film perfect." },
                { user: "Andrei S.", rating: 10, text: "Regia lui Coppola este impecabilă. O capodoperă absolută." },
                { user: "Laura T.", rating: 9, text: "Povestea te ține captivat de la început până la sfârșit." }
            ]
        },
        "Goodfellas": {
            descriere: "Un portret intens al lumii gangsterilor.",
            recenzie: "★★★★★ 9.5/10",
            an: 1990,
            rating: "9.5/10",
            gen: "Clasice",
            reviews: [
                { user: "Mihai C.", rating: 10, text: "Scorsese la cel mai bun nivel. Ritmul filmului este incredibil!" },
                { user: "Raluca N.", rating: 9, text: "Joe Pesci fură toate scenele. Performance excepțional." },
                { user: "Victor L.", rating: 10, text: "Cel mai realist film despre viața de gangster." }
            ]
        },
        "12 Angry Men": {
            descriere: "Drama puternică despre justiție și prejudecăți.",
            recenzie: "★★★★★ 9.5/10",
            an: 1957,
            rating: "9.5/10",
            gen: "Clasice",
            reviews: [
                { user: "Adrian F.", rating: 10, text: "Un masterclass în actorie și scenariu. Tensiunea crește constant." },
                { user: "Simona G.", rating: 9, text: "Toată acțiunea într-o singură cameră și totuși captivant!" },
                { user: "Robert H.", rating: 10, text: "Dialogurile sunt perfect scrise. Un film despre caracter." }
            ]
        },
        "The Dark Knight": {
            descriere: "Batman vs Joker: lupte morale și tensiune pură.",
            recenzie: "★★★★★ 10/10",
            an: 2008,
            rating: "10/10",
            gen: "Acțiune",
            reviews: [
                { user: "Cătălin P.", rating: 10, text: "Heath Ledger oferă cea mai bună interpretare a lui Joker. RIP." },
                { user: "Diana M.", rating: 10, text: "Nolan ridică filmele cu supereroi la un alt nivel." },
                { user: "Sorin A.", rating: 9, text: "Scenele de acțiune sunt spectaculoase, dar povestea e complexă." },
                { user: "Gabriela I.", rating: 10, text: "Un thriller psihologic deghizat în film de supereroi." }
            ]
        },
        "Gladiator": {
            descriere: "Epopeea epică a unui general roman.",
            recenzie: "★★★★★ 9.5/10",
            an: 2000,
            rating: "9.5/10",
            gen: "Acțiune",
            reviews: [
                { user: "Florin K.", rating: 10, text: "Russell Crowe este perfect în rol. Scenele de luptă sunt epice!" },
                { user: "Anca B.", rating: 9, text: "Soundtrack-ul lui Hans Zimmer completează perfect povestea." },
                { user: "Marius O.", rating: 10, text: "Are you not entertained?! Sunt foarte entertained!" }
            ]
        },
        "The Matrix": {
            descriere: "Un clasic SF cu lupte spectaculoase și filozofie.",
            recenzie: "★★★★★ 9/10",
            an: 1999,
            rating: "9/10",
            gen: "Acțiune",
            reviews: [
                { user: "George V.", rating: 10, text: "A schimbat cinematografia pentru totdeauna. Efecte vizuale revoluționare." },
                { user: "Alina C.", rating: 9, text: "Conceptul este minunat, dar devine confuz spre final." },
                { user: "Paul D.", rating: 10, text: "Filozofia din spatele acțiunii îl face special." }
            ]
        },
        "Casino Royale": {
            descriere: "James Bond revine în stil clasic cu multă tensiune.",
            recenzie: "★★★★★ 9/10",
            an: 2006,
            rating: "9/10",
            gen: "Acțiune",
            reviews: [
                { user: "Bogdan E.", rating: 9, text: "Daniel Craig reinventează personajul Bond. Mai dur, mai realist." },
                { user: "Oana F.", rating: 9, text: "Scena de poker este tensionată și foarte bine filmată." },
                { user: "Stefan M.", rating: 8, text: "Un reboot excelent pentru franciza Bond." }
            ]
        },
        "Fight Club": {
            descriere: "Explorarea identității și alienării.",
            recenzie: "★★★★★ 9.5/10",
            an: 1999,
            rating: "9.5/10",
            gen: "Psihologic",
            reviews: [
                { user: "Nicolae S.", rating: 10, text: "Plot twist-ul final este memorabil. Trebuie văzut de două ori!" },
                { user: "Andreea W.", rating: 9, text: "Un comentariu social puternic despre consumerism." },
                { user: "Radu I.", rating: 10, text: "Brad Pitt și Edward Norton au o chimie incredibilă." }
            ]
        },
        "Shutter Island": {
            descriere: "Thriller intens cu răsturnări de situație.",
            recenzie: "★★★★★ 9/10",
            an: 2010,
            rating: "9/10",
            gen: "Psihologic",
            reviews: [
                { user: "Carmen L.", rating: 9, text: "Atmosfera este copleșitoare. Te ține în suspans tot timpul." },
                { user: "Lucian T.", rating: 8, text: "DiCaprio excelent ca întotdeauna. Final surprinzător." },
                { user: "Monica R.", rating: 9, text: "Scorsese știe să construiască tensiune perfect." }
            ]
        },
        "Inception": {
            descriere: "Visuri și realitate se amestecă într-un mod spectaculos.",
            recenzie: "★★★★★ 10/10",
            an: 2010,
            rating: "10/10",
            gen: "Psihologic",
            reviews: [
                { user: "Vlad N.", rating: 10, text: "Nolan la apogeu. Conceptul este genial executat!" },
                { user: "Isabella P.", rating: 10, text: "Efecte vizuale uimitoare și poveste complexă. Masterpiece!" },
                { user: "Cosmin D.", rating: 9, text: "Trebuie să fii atent la fiecare detaliu. Merită văzut de mai multe ori." },
                { user: "Bianca G.", rating: 10, text: "Soundtrack-ul perfect și cinematografie de vis." }
            ]
        },
        "Black Swan": {
            descriere: "Obsesiile și presiunile lumii baletului.",
            recenzie: "★★★★★ 9/10",
            an: 2010,
            rating: "9/10",
            gen: "Psihologic",
            reviews: [
                { user: "Roxana M.", rating: 9, text: "Natalie Portman livrează o performanță intensă și tulburătoare." },
                { user: "Adrian C.", rating: 8, text: "Vizual stunning dar destul de perturbant psihologic." },
                { user: "Irina F.", rating: 10, text: "Aronofsky creează o atmosferă claustrofobă perfectă." }
            ]
        },
        "Forrest Gump": {
            descriere: "O viață plină de aventuri și emoții pure.",
            recenzie: "★★★★★ 10/10",
            an: 1994,
            rating: "10/10",
            gen: "Dramă",
            reviews: [
                { user: "Teodora V.", rating: 10, text: "M-a făcut să plâng și să râd. Tom Hanks este extraordinar!" },
                { user: "Gabriel K.", rating: 10, text: "O călătorie emoțională prin istoria Americii." },
                { user: "Daria S.", rating: 9, text: "Un film care te inspiră să nu renunți niciodată." },
                { user: "Matei R.", rating: 10, text: "Life is like a box of chocolates - și acest film este dulce!" }
            ]
        },
        "The Pursuit of Happyness": {
            descriere: "O poveste emoționantă despre speranță și curaj.",
            recenzie: "★★★★★ 9.5/10",
            an: 2006,
            rating: "9.5/10",
            gen: "Dramă",
            reviews: [
                { user: "Eliza P.", rating: 10, text: "Will Smith și fiul său sunt incredibili împreună. Foarte emoționant!" },
                { user: "Rareș M.", rating: 9, text: "O poveste inspirațională bazată pe fapte reale. Motivant!" },
                { user: "Ana J.", rating: 10, text: "Am plâns în mai multe scene. Un film despre perseverență." }
            ]
        },
        "Moonlight": {
            descriere: "Explorarea identității și dragostei într-un context dificil.",
            recenzie: "★★★★★ 9/10",
            an: 2016,
            rating: "9/10",
            gen: "Dramă",
            reviews: [
                { user: "Larisa D.", rating: 9, text: "Un film sensibil și profund despre identitate și acceptare." },
                { user: "Felix O.", rating: 8, text: "Cinematografie superbă. O poveste foarte personală." },
                { user: "Claudia N.", rating: 9, text: "Meritat câștigător la Oscar. Emoționant și autentic." }
            ]
        },
        "Requiem for a Dream": {
            descriere: "O poveste dureroasă despre dependență și pierdere.",
            recenzie: "★★★★★ 9/10",
            an: 2000,
            rating: "9/10",
            gen: "Dramă",
            reviews: [
                { user: "Sergiu L.", rating: 9, text: "Perturbator și greu de uitat. Un avertisment puternic." },
                { user: "Valentina I.", rating: 8, text: "Foarte intens emoțional. Nu e un film ușor de privit." },
                { user: "Dorin C.", rating: 9, text: "Montajul și muzica creează o experiență viscerală." }
            ]
        },
        "LOTR: Return of the King": {
            descriere: "Finalul epic al trilogiei Lord of the Rings.",
            recenzie: "★★★★★ 10/10",
            an: 2003,
            rating: "10/10",
            gen: "SF/Fantezie",
            reviews: [
                { user: "Patricia H.", rating: 10, text: "Finalul perfect pentru cea mai bună trilogie ever made!" },
                { user: "Cristi B.", rating: 10, text: "Emoționant, epic și vizual spectaculos. Peter Jackson e un geniu." },
                { user: "Sabina A.", rating: 10, text: "Am plâns la final. 11 Oscaruri pe bună dreptate!" },
                { user: "Dragoș F.", rating: 9, text: "Prea multe finaluri, dar overall este fantastic." }
            ]
        },
        "Interstellar": {
            descriere: "O odisee spațială emoționantă și vizual spectaculoasă.",
            recenzie: "★★★★★ 10/10",
            an: 2014,
            rating: "10/10",
            gen: "SF/Fantezie",
            reviews: [
                { user: "Octavian M.", rating: 10, text: "Nolan combină știința cu emoția. Scena cu Murph m-a distrus!" },
                { user: "Silvia G.", rating: 10, text: "Hans Zimmer creează un soundtrack epic. Vizualuri uimitoare!" },
                { user: "Tudor P.", rating: 9, text: "Complexitatea științifică e fascinantă. Ceva confuz uneori." },
                { user: "Nicoleta E.", rating: 10, text: "Un film despre dragoste dincolo de timp și spațiu." }
            ]
        },
        "Avatar": {
            descriere: "O aventură vizuală în lumea Pandora.",
            recenzie: "★★★★★ 9/10",
            an: 2009,
            rating: "9/10",
            gen: "SF/Fantezie",
            reviews: [
                { user: "Cătălina R.", rating: 9, text: "Efectele vizuale sunt revoluționare. Pandora arată incredibil!" },
                { user: "Vasile N.", rating: 8, text: "Vizual superb dar povestea e predictibilă." },
                { user: "Denisa T.", rating: 9, text: "3D-ul cel mai bun văzut vreodată. O experiență cinematografică." }
            ]
        },
        "Blade Runner 2049": {
            descriere: "O continuare impresionantă a clasicului Blade Runner.",
            recenzie: "★★★★★ 9/10",
            an: 2017,
            rating: "9/10",
            gen: "SF/Fantezie",
            reviews: [
                { user: "Emil V.", rating: 10, text: "Villeneuve creează o atmosferă unică. Cinematografie de vis!" },
                { user: "Georgiana S.", rating: 9, text: "Ryan Gosling perfect în rol. Vizual stunning!" },
                { user: "Horia C.", rating: 8, text: "Puțin cam lent, dar foarte frumos vizual." }
            ]
        },
        "La La Land": {
            descriere: "O poveste romantică și muzicală plină de energie.",
            recenzie: "★★★★★ 9/10",
            an: 2016,
            rating: "9/10",
            gen: "Muzical",
            reviews: [
                { user: "Mihaela O.", rating: 9, text: "Emma Stone și Ryan Gosling au o chimie magică!" },
                { user: "Cristian Z.", rating: 8, text: "Cinematografie de vis. Finalul m-a lăsat gânditor." },
                { user: "Ioana K.", rating: 10, text: "Muzica și dansurile sunt superbe. Un musical modern!" }
            ]
        },
        "Whiplash": {
            descriere: "Intensitatea muzicii și a relației profesor-elev.",
            recenzie: "★★★★★ 9/10",
            an: 2014,
            rating: "9/10",
            gen: "Muzical",
            reviews: [
                { user: "Alexandru W.", rating: 10, text: "J.K. Simmons e terifiant și fascinant. Scena finală e perfectă!" },
                { user: "Ramona L.", rating: 9, text: "Intens și stresant. Muzica de jazz e incredibilă." },
                { user: "Ciprian D.", rating: 10, text: "Cel mai bun film despre obsesie și perfecționism." }
            ]
        },
        "The Greatest Showman": {
            descriere: "Spectacolul continuu al unei povești inspiraționale.",
            recenzie: "★★★★★ 9/10",
            an: 2017,
            rating: "9/10",
            gen: "Muzical",
            reviews: [
                { user: "Loredana M.", rating: 9, text: "Muzica e catchy și inspirațională. Hugh Jackman e superb!" },
                { user: "Ștefan I.", rating: 8, text: "Feel-good movie perfect. Cântecele rămân în cap." },
                { user: "Adina P.", rating: 9, text: "Colorat, energetic și emoționant. Copiii mei îl adoră!" }
            ]
        },
        "The Notebook": {
            descriere: "O poveste de dragoste clasică și emoționantă.",
            recenzie: "★★★★★ 9/10",
            an: 2004,
            rating: "9/10",
            gen: "Romantic",
            reviews: [
                { user: "Cosmina F.", rating: 10, text: "Am plâns ca un copil. Ryan Gosling e perfect romantic!" },
                { user: "Laurențiu G.", rating: 8, text: "Clasic romantic. Rachel McAdams și Gosling au chimie." },
                { user: "Magdalena V.", rating: 9, text: "Povestea de dragoste definitivă. Emoționant până la lacrimi!" }
            ]
        },
        "500 Days of Summer": {
            descriere: "O explorare modernă a iubirii și despărțirilor.",
            recenzie: "★★★★★ 8.5/10",
            an: 2009,
            rating: "8.5/10",
            gen: "Romantic",
            reviews: [
                { user: "Daniela H.", rating: 9, text: "O viziune realistă asupra dragostei. Zooey Deschanel e adorabilă!" },
                { user: "Marian S.", rating: 8, text: "Scena expectations vs reality e genială." },
                { user: "Lavinia T.", rating: 8, text: "Nu e un film de dragoste clasic și asta îl face special." }
            ]
        },
        "Call Me by Your Name": {
            descriere: "O poveste sensibilă despre descoperirea iubirii.",
            recenzie: "★★★★★ 9/10",
            an: 2017,
            rating: "9/10",
            gen: "Romantic",
            reviews: [
                { user: "Raluca E.", rating: 10, text: "Timothée Chalamet e revelația filmului. Emoționant și sensibil!" },
                { user: "Ionel B.", rating: 9, text: "Atmosfera verii italiene e captivantă. Foarte frumos filmat." },
                { user: "Camelia N.", rating: 9, text: "O poveste de dragoste autentică și profundă." }
            ]
        }
    };

    // Afișează detaliile filmului la click
    cards.forEach(card => {
        card.addEventListener("click", () => {
            const filmName = card.getAttribute("data-title");
            if (filmeInfo[filmName]) {
                const film = filmeInfo[filmName];
                modalTitle.textContent = filmName;
                modalGenre.textContent = film.gen;
                modalYear.textContent = film.an;
                modalRating.textContent = film.rating;
                modalReview.textContent = film.descriere;
                
                // Set up reviews
                currentReviews = film.reviews || [];
                displayedReviewsCount = 0;
                reviewsList.innerHTML = '';
                
                // Display first 2 reviews
                displayReviews(2);
                
                // Show/hide "Show More" button
                if (currentReviews.length > 2) {
                    showMoreBtn.style.display = 'block';
                    showMoreBtn.textContent = 'Arată mai multe ↓';
                } else {
                    showMoreBtn.style.display = 'none';
                }
                
                modal.style.display = "block";
            }
        });
    });

    // Function to display reviews
    function displayReviews(count) {
        const reviewsToShow = currentReviews.slice(displayedReviewsCount, displayedReviewsCount + count);
        
        reviewsToShow.forEach(review => {
            const reviewCard = document.createElement('div');
            reviewCard.className = 'review-card';
            
            const stars = '★'.repeat(review.rating) + '☆'.repeat(10 - review.rating);
            
            reviewCard.innerHTML = `
                <div class="review-header">
                    <span class="review-user">👤 ${review.user}</span>
                    <span class="review-rating">${stars} ${review.rating}/10</span>
                </div>
                <p class="review-text">${review.text}</p>
            `;
            
            reviewsList.appendChild(reviewCard);
        });
        
        displayedReviewsCount += reviewsToShow.length;
        
        // Update or hide "Show More" button
        if (displayedReviewsCount >= currentReviews.length) {
            showMoreBtn.style.display = 'none';
        }
    }

    // Show More button click handler
    showMoreBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        displayReviews(2); // Load 2 more reviews each time
    });

    // Închide modalul
    closeBtn.addEventListener("click", () => {
        modal.style.display = "none";
    });

    // Închide modalul dacă se face click în afara acestuia
    window.addEventListener("click", (e) => {
        if (e.target === modal) {
            modal.style.display = "none";
        }
    });
});
