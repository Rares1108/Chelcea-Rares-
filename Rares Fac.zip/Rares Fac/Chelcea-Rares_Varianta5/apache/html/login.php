<?php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get POST data
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Validate input
if (empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Te rog completează toate câmpurile']);
    exit;
}

// Connect to database
$conn = getDBConnection();

// Prepare and execute query
$stmt = $conn->prepare("SELECT id, nume, prenume, email, parola FROM utilizatori WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Email sau parolă incorectă']);
    $stmt->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();

// Verify password
if (password_verify($password, $user['parola'])) {
    // Update last login time
    $updateStmt = $conn->prepare("UPDATE utilizatori SET ultima_autentificare = CURRENT_TIMESTAMP WHERE id = ?");
    $updateStmt->bind_param("i", $user['id']);
    $updateStmt->execute();
    $updateStmt->close();
    
    // Set session variables
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['prenume'] . ' ' . $user['nume'];
    $_SESSION['user_email'] = $user['email'];
    
    echo json_encode([
        'success' => true, 
        'message' => 'Autentificare reușită!',
        'user' => [
            'id' => $user['id'],
            'name' => $user['prenume'] . ' ' . $user['nume'],
            'email' => $user['email']
        ]
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Email sau parolă incorectă']);
}

$stmt->close();
$conn->close();
?>
