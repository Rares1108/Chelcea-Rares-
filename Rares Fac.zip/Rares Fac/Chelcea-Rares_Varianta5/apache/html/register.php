<?php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get POST data
$firstname = $_POST['firstname'] ?? '';
$lastname = $_POST['lastname'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$confirmPassword = $_POST['confirmPassword'] ?? '';

// Validate input
if (empty($firstname) || empty($lastname) || empty($email) || empty($password) || empty($confirmPassword)) {
    echo json_encode(['success' => false, 'message' => 'Te rog completează toate câmpurile']);
    exit;
}

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Email invalid']);
    exit;
}

// Validate password match
if ($password !== $confirmPassword) {
    echo json_encode(['success' => false, 'message' => 'Parolele nu coincid']);
    exit;
}

// Validate password strength (minimum 6 characters)
if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'Parola trebuie să aibă minim 6 caractere']);
    exit;
}

// Connect to database
$conn = getDBConnection();

// Check if email already exists
$checkStmt = $conn->prepare("SELECT id FROM utilizatori WHERE email = ?");
$checkStmt->bind_param("s", $email);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Acest email este deja înregistrat']);
    $checkStmt->close();
    $conn->close();
    exit;
}
$checkStmt->close();

// Hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Insert new user
$stmt = $conn->prepare("INSERT INTO utilizatori (nume, prenume, email, parola) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $lastname, $firstname, $email, $hashedPassword);

if ($stmt->execute()) {
    $userId = $stmt->insert_id;
    
    // Set session variables
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_name'] = $firstname . ' ' . $lastname;
    $_SESSION['user_email'] = $email;
    
    echo json_encode([
        'success' => true, 
        'message' => 'Contul a fost creat cu succes!',
        'user' => [
            'id' => $userId,
            'name' => $firstname . ' ' . $lastname,
            'email' => $email
        ]
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Eroare la crearea contului: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>
