// Shared search logic for Top Filme
(function(){
  function displayResultsOnTopFilme(movies){
    const container = document.querySelector('.container');
    if(!container) return;
    let results = document.getElementById('top-search-results');
    if(!results){
      results = document.createElement('section');
      results.id = 'top-search-results';
      results.className = 'genre';
      results.innerHTML = '<h2>🔎 Rezultate căutare</h2><div class="top-filme" id="top-search-cards"></div>';
      container.insertBefore(results, container.firstChild);
    }
    const cardsWrap = document.getElementById('top-search-cards');
    cardsWrap.innerHTML = '';
    movies.forEach(m => {
      const card = document.createElement('div');
      card.className = 'card';
      card.setAttribute('data-title', m.title || '');
      card.innerHTML = `
        <img src="${m.poster || 'images/placeholder.jpg'}" alt="${m.title}">
        <div class="card-content"><h3>${m.title}</h3></div>
      `;
      cardsWrap.appendChild(card);
    });
  }

  function collectLocalTitles(){
    // Collect titles from current page cards
    const titles = [];
    document.querySelectorAll('.card').forEach(card => {
      const h = card.querySelector('h3');
      if(h){
        titles.push({
          title: h.textContent.trim(),
          poster: (card.querySelector('img') || {}).src || ''
        });
      }
    });
    return titles;
  }

  async function fetchFeatured(){
    try{
      const res = await fetch('featured.json');
      const data = await res.json();
      return Array.isArray(data) ? data : [];
    }catch{ return []; }
  }

  function normalizeTitle(t){
    return (t || '').toLowerCase().trim();
  }

  async function performSearchTopFilme(query){
    try{
      const response = await fetch(`search-movies.php?q=${encodeURIComponent(query)}`);
      const result = await response.json();
      // Filter DB movies by title match client-side as safety
      const dbAll = (result.success && Array.isArray(result.movies)) ? result.movies : [];
      const dbMovies = dbAll.filter(m => normalizeTitle(m.title).includes(normalizeTitle(query)));
      const local = collectLocalTitles().filter(t => normalizeTitle(t.title).includes(normalizeTitle(query)));
      const featured = (await fetchFeatured()).filter(f => normalizeTitle(f.title).includes(normalizeTitle(query)));
      // Merge all and dedupe by normalized title
      const seen = new Set();
      const merged = [...local, ...featured, ...dbMovies].filter(item => {
        const key = normalizeTitle(item.title);
        if(!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      displayResultsOnTopFilme(merged);
    }catch(err){
      console.error('Search error:', err);
      const local = collectLocalTitles().filter(t => normalizeTitle(t.title).includes(normalizeTitle(query)));
      const featured = (await fetchFeatured()).filter(f => normalizeTitle(f.title).includes(normalizeTitle(query)));
      const seen = new Set();
      const merged = [...local, ...featured].filter(item => {
        const key = normalizeTitle(item.title);
        if(!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      if(merged.length){ displayResultsOnTopFilme(merged); } else { showNoResults(query); }
    }
  }

  function showNoResults(query){
    let results = document.getElementById('top-search-results');
    if(!results){
      const container = document.querySelector('.container');
      if(!container) return;
      results = document.createElement('section');
      results.id = 'top-search-results';
      results.className = 'genre';
      container.insertBefore(results, container.firstChild);
    }
    results.innerHTML = `<div style="text-align:center; padding:1rem; color:#ddd;">Nu s-au găsit rezultate pentru "${query}"</div>`;
  }

  function wireSearchBar(){
    const input = document.getElementById('search');
    const btn = document.getElementById('searchBtn');
    if(!input) return;
    let t;
    const go = ()=>{
      const q = input.value.trim();
      if(q.length < 2){ return; }
      performSearchTopFilme(q);
    };
    input.addEventListener('keyup', (e)=>{
      clearTimeout(t); t = setTimeout(go, 250);
      if(e.key === 'Enter') go();
    });
    if(btn){ btn.addEventListener('click', go); }
  }

  document.addEventListener('DOMContentLoaded', wireSearchBar);
})();
