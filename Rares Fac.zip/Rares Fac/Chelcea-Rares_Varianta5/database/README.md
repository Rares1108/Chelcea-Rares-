# Baza de Date CineRecenzii

## Prezentare Generală

Aceasta este baza de date MySQL pentru site-ul de recenzii filme **CineRecenzii**. Baza de date include toate structurile necesare pentru gestionarea utilizatorilor, filmelor, recenziilor, comentariilor și interacțiunilor.

## Structura Bazei de Date

### Tabele Principale

1. **utilizatori** - Informații despre utilizatori
   - id, nume, prenume, email, parola
   - data_inregistrare, ultima_autentificare, avatar

2. **filme** - Catalogul de filme
   - id, titlu, titlu_original, an_aparitie
   - durata, descriere, regizor, actori
   - poster, trailer_url, data_adaugare

3. **genuri** - Genurile de filme
   - id, nume, descriere, icona

4. **recenzii** - Recenziile utilizatorilor
   - id, film_id, utilizator_id
   - rating (0-10), titlu, continut
   - likes, dislikes
   - data_publicare, data_editare

5. **comentarii** - Comentarii la recenzii
   - id, recenzie_id, utilizator_id, continut
   - data_publicare, data_editare

### Tabele de Legătură

6. **filme_genuri** - Relație many-to-many între filme și genuri
7. **recenzii_rating** - Like/dislike la recenzii
8. **favorite** - Filme favorite ale utilizatorilor
9. **watchlist** - Liste de filme de văzut

## Instalare

### Metoda 1: MySQL Command Line

```bash
mysql -u root -p < init.sql
```

### Metoda 2: MySQL Workbench

1. Deschide MySQL Workbench
2. Conectează-te la serverul MySQL
3. File → Open SQL Script
4. Selectează `init.sql`
5. Execută scriptul (Ctrl+Shift+Enter)

### Metoda 3: phpMyAdmin

1. Accesează phpMyAdmin
2. Click pe tab-ul "Import"
3. Selectează fișierul `init.sql`
4. Click "Go"

### Metoda 4: Docker (din docker-compose.yml existent)

```bash
# Copiază init.sql în container
docker cp database/init.sql mysql:/docker-entrypoint-initdb.d/

# Sau montează volumul în docker-compose.yml:
# volumes:
#   - ./database/init.sql:/docker-entrypoint-initdb.d/init.sql
```

## Date Inițiale

Baza de date vine pre-populată cu:

- **10 genuri** de filme (Clasice, Acțiune, Psihologic, etc.)
- **26 filme** populare din diverse genuri
- **5 utilizatori** de test (parola: `password123`)
- **15 recenzii** exemple
- **7 comentarii** la recenzii
- Multiple **filme favorite** și **watchlist** entries

## Views (Vederi)

### filme_rating
Afișează rating-ul mediu și numărul de recenzii pentru fiecare film.

```sql
SELECT * FROM filme_rating;
```

### top_filme
Clasament filme după rating mediu și popularitate.

```sql
SELECT * FROM top_filme LIMIT 10;
```

### utilizatori_activi
Statistici despre activitatea utilizatorilor.

```sql
SELECT * FROM utilizatori_activi;
```

## Stored Procedures (Proceduri Stocate)

### 1. adauga_recenzie
Adaugă o recenzie nouă pentru un film.

```sql
CALL adauga_recenzie(5, 1, 9.5, 'Foarte bun!', 'Un film excelent care...');
```

**Parametri:**
- `p_film_id` - ID-ul filmului
- `p_utilizator_id` - ID-ul utilizatorului
- `p_rating` - Rating (0-10)
- `p_titlu` - Titlul recenziei
- `p_continut` - Conținutul recenziei

### 2. cauta_filme
Caută filme după cuvinte cheie în titlu, descriere sau regizor.

```sql
CALL cauta_filme('Nolan');
CALL cauta_filme('science fiction');
```

### 3. statistici_utilizator
Afișează statistici complete pentru un utilizator.

```sql
CALL statistici_utilizator(1);
```

## Triggers (Declanșatoare)

### after_recenzie_rating_insert/delete
Actualizează automat numărul de likes/dislikes din tabela `recenzii` când se adaugă sau șterge un rating.

## Query-uri Utile

### Top 10 filme după rating
```sql
SELECT * FROM top_filme LIMIT 10;
```

### Recenzii recente
```sql
SELECT 
    r.titlu,
    f.titlu as film,
    CONCAT(u.nume, ' ', u.prenume) as autor,
    r.rating,
    r.data_publicare
FROM recenzii r
JOIN filme f ON r.film_id = f.id
JOIN utilizatori u ON r.utilizator_id = u.id
ORDER BY r.data_publicare DESC
LIMIT 10;
```

### Filme după gen
```sql
SELECT 
    f.titlu,
    f.an_aparitie,
    GROUP_CONCAT(g.nume SEPARATOR ', ') as genuri
FROM filme f
JOIN filme_genuri fg ON f.id = fg.film_id
JOIN genuri g ON fg.gen_id = g.id
WHERE g.nume = 'Acțiune'
GROUP BY f.id, f.titlu, f.an_aparitie;
```

### Utilizatori cu cele mai multe recenzii
```sql
SELECT 
    CONCAT(u.nume, ' ', u.prenume) as utilizator,
    COUNT(r.id) as numar_recenzii,
    ROUND(AVG(r.rating), 1) as rating_mediu_acordat
FROM utilizatori u
JOIN recenzii r ON u.id = r.utilizator_id
GROUP BY u.id, u.nume, u.prenume
ORDER BY numar_recenzii DESC;
```

### Filme populare (cele mai multe favorite)
```sql
SELECT 
    f.titlu,
    COUNT(fav.id) as numar_favorite,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM filme f
LEFT JOIN favorite fav ON f.id = fav.film_id
LEFT JOIN recenzii r ON f.id = r.film_id
GROUP BY f.id, f.titlu
ORDER BY numar_favorite DESC
LIMIT 10;
```

## Securitate

### Parolele
- Parolele utilizatorilor sunt stocate criptat folosind **bcrypt** (hash: `$2y$10$...`)
- În exemplele de test, parola este `password123`
- **IMPORTANT:** În producție, folosește întotdeauna hashing puternic (bcrypt, argon2)

### Best Practices
1. **Nu stoca niciodată parole în text clar**
2. Folosește prepared statements pentru a preveni SQL injection
3. Validează și sanitizează toate input-urile utilizatorilor
4. Implementează rate limiting pentru login și înregistrare
5. Folosește HTTPS pentru toate conexiunile
6. Creează utilizatori MySQL cu privilegii limitate pentru aplicație

## Conexiune din PHP

```php
<?php
$host = 'localhost';
$dbname = 'cinerecenzii';
$username = 'root';
$password = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    die("Eroare conexiune: " . $e->getMessage());
}
?>
```

## Backup și Restore

### Backup
```bash
mysqldump -u root -p cinerecenzii > backup_cinerecenzii.sql
```

### Restore
```bash
mysql -u root -p cinerecenzii < backup_cinerecenzii.sql
```

## Extinderi Viitoare

Posibile îmbunătățiri:
- [ ] Sistem de notificări pentru utilizatori
- [ ] Mesaje private între utilizatori
- [ ] Sistem de badges/achievements
- [ ] Histórico de modificări pentru recenzii
- [ ] Raportare conținut inadecvat
- [ ] Suport multilingv
- [ ] Integrare API-uri externe (TMDB, IMDB)
- [ ] Sistem de recomandări bazat pe ML

## Support

Pentru întrebări sau probleme:
- Email: support@cinerecenzii.ro
- GitHub Issues: [link]

## Licență

MIT License - 2025 CineRecenzii
