-- Baza de date pentru CineRecenzii
-- Creat: 28 noiembrie 2025

-- Creare bază de date
CREATE DATABASE IF NOT EXISTS cinerecenzii CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cinerecenzii;

-- Tabela pentru utilizatori
CREATE TABLE IF NOT EXISTS utilizatori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nume VARCHAR(100) NOT NULL,
    prenume VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    parola VARCHAR(255) NOT NULL,
    data_inregistrare TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultima_autentificare TIMESTAMP NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela pentru genuri de filme
CREATE TABLE IF NOT EXISTS genuri (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nume VARCHAR(50) UNIQUE NOT NULL,
    descriere TEXT,
    icona VARCHAR(10)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela pentru filme
CREATE TABLE IF NOT EXISTS filme (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titlu VARCHAR(255) NOT NULL,
    titlu_original VARCHAR(255),
    an_aparitie YEAR NOT NULL,
    durata INT, -- în minute
    descriere TEXT,
    regizor VARCHAR(255),
    actori TEXT,
    poster VARCHAR(255),
    trailer_url VARCHAR(500),
    data_adaugare TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_titlu (titlu),
    INDEX idx_an (an_aparitie)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de legătură filme-genuri (many-to-many)
CREATE TABLE IF NOT EXISTS filme_genuri (
    film_id INT NOT NULL,
    gen_id INT NOT NULL,
    PRIMARY KEY (film_id, gen_id),
    FOREIGN KEY (film_id) REFERENCES filme(id) ON DELETE CASCADE,
    FOREIGN KEY (gen_id) REFERENCES genuri(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela pentru recenzii
CREATE TABLE IF NOT EXISTS recenzii (
    id INT AUTO_INCREMENT PRIMARY KEY,
    film_id INT NOT NULL,
    utilizator_id INT NOT NULL,
    rating DECIMAL(3,1) CHECK (rating >= 0 AND rating <= 10),
    titlu VARCHAR(255) NOT NULL,
    continut TEXT NOT NULL,
    data_publicare TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_editare TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    likes INT DEFAULT 0,
    dislikes INT DEFAULT 0,
    FOREIGN KEY (film_id) REFERENCES filme(id) ON DELETE CASCADE,
    FOREIGN KEY (utilizator_id) REFERENCES utilizatori(id) ON DELETE CASCADE,
    INDEX idx_film (film_id),
    INDEX idx_utilizator (utilizator_id),
    INDEX idx_rating (rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela pentru comentarii la recenzii
CREATE TABLE IF NOT EXISTS comentarii (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recenzie_id INT NOT NULL,
    utilizator_id INT NOT NULL,
    continut TEXT NOT NULL,
    data_publicare TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_editare TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (recenzie_id) REFERENCES recenzii(id) ON DELETE CASCADE,
    FOREIGN KEY (utilizator_id) REFERENCES utilizatori(id) ON DELETE CASCADE,
    INDEX idx_recenzie (recenzie_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela pentru rating-uri (like/dislike) la recenzii
CREATE TABLE IF NOT EXISTS recenzii_rating (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recenzie_id INT NOT NULL,
    utilizator_id INT NOT NULL,
    tip ENUM('like', 'dislike') NOT NULL,
    data_rating TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_rating (recenzie_id, utilizator_id),
    FOREIGN KEY (recenzie_id) REFERENCES recenzii(id) ON DELETE CASCADE,
    FOREIGN KEY (utilizator_id) REFERENCES utilizatori(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela pentru filme favorite
CREATE TABLE IF NOT EXISTS favorite (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilizator_id INT NOT NULL,
    film_id INT NOT NULL,
    data_adaugare TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_favorite (utilizator_id, film_id),
    FOREIGN KEY (utilizator_id) REFERENCES utilizatori(id) ON DELETE CASCADE,
    FOREIGN KEY (film_id) REFERENCES filme(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela pentru watchlist (de văzut)
CREATE TABLE IF NOT EXISTS watchlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilizator_id INT NOT NULL,
    film_id INT NOT NULL,
    data_adaugare TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_watchlist (utilizator_id, film_id),
    FOREIGN KEY (utilizator_id) REFERENCES utilizatori(id) ON DELETE CASCADE,
    FOREIGN KEY (film_id) REFERENCES filme(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================
-- DATE INIȚIALE - GENURI
-- ==============================================

INSERT INTO genuri (nume, descriere, icona) VALUES
('Clasice', 'Filme clasice care au marcat istoria cinematografiei', '🎬'),
('Acțiune', 'Filme cu scene de acțiune și aventură', '⚔️'),
('Psihologic', 'Thrilere psihologice și filme complexe', '🧠'),
('Dramă', 'Filme dramatice și emoționante', '🎭'),
('SF/Fantezie', 'Science Fiction și Fantasy', '🎥'),
('Muzical', 'Filme muzicale și de dans', '🎶'),
('Romantic', 'Filme romantice', '💔'),
('Horror', 'Filme de groază', '👻'),
('Comedie', 'Filme comice', '😄'),
('Thriller', 'Filme thriller și suspans', '🔪');

-- ==============================================
-- DATE INIȚIALE - FILME
-- ==============================================

INSERT INTO filme (titlu, titlu_original, an_aparitie, durata, descriere, regizor, actori, poster) VALUES
-- Clasice
('Citizen Kane', 'Citizen Kane', 1941, 119, 'Un film clasic despre putere și ambiție.', 'Orson Welles', 'Orson Welles, Joseph Cotten, Dorothy Comingore', 'images/citizen-kane.jpg'),
('The Godfather', 'The Godfather', 1972, 175, 'Povestea legendară a familiei mafiote Corleone.', 'Francis Ford Coppola', 'Marlon Brando, Al Pacino, James Caan', 'images/godfather.jpg'),
('Goodfellas', 'Goodfellas', 1990, 146, 'Un portret intens al lumii gangsterilor.', 'Martin Scorsese', 'Robert De Niro, Ray Liotta, Joe Pesci', 'images/goodfellas.jpg'),
('12 Angry Men', '12 Angry Men', 1957, 96, 'Drama puternică despre justiție și prejudecăți.', 'Sidney Lumet', 'Henry Fonda, Lee J. Cobb, Martin Balsam', 'images/12-angry-men.jpg'),

-- Acțiune
('The Dark Knight', 'The Dark Knight', 2008, 152, 'Batman vs Joker: lupte morale și tensiune pură.', 'Christopher Nolan', 'Christian Bale, Heath Ledger, Aaron Eckhart', 'images/dark-knight.jpg'),
('Gladiator', 'Gladiator', 2000, 155, 'Epopeea epică a unui general roman.', 'Ridley Scott', 'Russell Crowe, Joaquin Phoenix, Connie Nielsen', 'images/gladiator.jpg'),
('The Matrix', 'The Matrix', 1999, 136, 'Un clasic SF cu lupte spectaculoase și filozofie.', 'Lana Wachowski, Lilly Wachowski', 'Keanu Reeves, Laurence Fishburne, Carrie-Anne Moss', 'images/matrix.jpg'),
('Casino Royale', 'Casino Royale', 2006, 144, 'James Bond revine în stil clasic cu multă tensiune.', 'Martin Campbell', 'Daniel Craig, Eva Green, Mads Mikkelsen', 'images/casino-royale.jpg'),

-- Psihologice
('Fight Club', 'Fight Club', 1999, 139, 'Explorarea identității și alienării.', 'David Fincher', 'Brad Pitt, Edward Norton, Helena Bonham Carter', 'images/fight-club.jpg'),
('Shutter Island', 'Shutter Island', 2010, 138, 'Thriller intens cu răsturnări de situație.', 'Martin Scorsese', 'Leonardo DiCaprio, Mark Ruffalo, Ben Kingsley', 'images/shutter-island.jpg'),
('Inception', 'Inception', 2010, 148, 'Visuri și realitate se amestecă într-un mod spectaculos.', 'Christopher Nolan', 'Leonardo DiCaprio, Joseph Gordon-Levitt, Ellen Page', 'images/inception.jpg'),
('Black Swan', 'Black Swan', 2010, 108, 'Obsesiile și presiunile lumii baletului.', 'Darren Aronofsky', 'Natalie Portman, Mila Kunis, Vincent Cassel', 'images/black-swan.jpg'),

-- Dramă
('Forrest Gump', 'Forrest Gump', 1994, 142, 'O viață plină de aventuri și emoții pure.', 'Robert Zemeckis', 'Tom Hanks, Robin Wright, Gary Sinise', 'images/forrest-gump.jpg'),
('The Pursuit of Happyness', 'The Pursuit of Happyness', 2006, 117, 'O poveste emoționantă despre speranță și curaj.', 'Gabriele Muccino', 'Will Smith, Jaden Smith, Thandie Newton', 'images/pursuit-of-happyness.jpg'),
('Moonlight', 'Moonlight', 2016, 111, 'Explorarea identității și dragostei într-un context dificil.', 'Barry Jenkins', 'Mahershala Ali, Naomie Harris, Trevante Rhodes', 'images/moonlight.jpg'),
('Requiem for a Dream', 'Requiem for a Dream', 2000, 102, 'O poveste dureroasă despre dependență și pierdere.', 'Darren Aronofsky', 'Ellen Burstyn, Jared Leto, Jennifer Connelly', 'images/requiem-for-a-dream.jpg'),

-- SF/Fantezie
('LOTR: Return of the King', 'The Lord of the Rings: The Return of the King', 2003, 201, 'Finalul epic al trilogiei Lord of the Rings.', 'Peter Jackson', 'Elijah Wood, Viggo Mortensen, Ian McKellen', 'images/lotr-return.jpg'),
('Interstellar', 'Interstellar', 2014, 169, 'O odisee spațială emoționantă și vizual spectaculoasă.', 'Christopher Nolan', 'Matthew McConaughey, Anne Hathaway, Jessica Chastain', 'images/interstellar.jpg'),
('Avatar', 'Avatar', 2009, 162, 'O aventură vizuală în lumea Pandora.', 'James Cameron', 'Sam Worthington, Zoe Saldana, Sigourney Weaver', 'images/avatar.jfif'),
('Blade Runner 2049', 'Blade Runner 2049', 2017, 164, 'O continuare impresionantă a clasicului Blade Runner.', 'Denis Villeneuve', 'Ryan Gosling, Harrison Ford, Ana de Armas', 'images/blade-runner-2049.jfif'),

-- Muzicale
('La La Land', 'La La Land', 2016, 128, 'O poveste romantică și muzicală plină de energie.', 'Damien Chazelle', 'Ryan Gosling, Emma Stone, John Legend', 'images/la-la-land.png'),
('Whiplash', 'Whiplash', 2014, 106, 'Intensitatea muzicii și a relației profesor-elev.', 'Damien Chazelle', 'Miles Teller, J.K. Simmons, Paul Reiser', 'images/whiplash.jpg'),
('The Greatest Showman', 'The Greatest Showman', 2017, 105, 'Spectacolul continuu al unei povești inspiraționale.', 'Michael Gracey', 'Hugh Jackman, Michelle Williams, Zac Efron', 'images/greatest-showman.jfif'),

-- Romantice
('The Notebook', 'The Notebook', 2004, 123, 'O poveste de dragoste clasică și emoționantă.', 'Nick Cassavetes', 'Ryan Gosling, Rachel McAdams, James Garner', 'images/the-notebook.jfif'),
('500 Days of Summer', '500 Days of Summer', 2009, 95, 'O explorare modernă a iubirii și despărțirilor.', 'Marc Webb', 'Joseph Gordon-Levitt, Zooey Deschanel', 'images/500-days-of-summer.jfif'),
('Call Me by Your Name', 'Call Me by Your Name', 2017, 132, 'O poveste sensibilă despre descoperirea iubirii.', 'Luca Guadagnino', 'Timothée Chalamet, Armie Hammer, Michael Stuhlbarg', 'images/call-me-by-your-name.jfif');

-- ==============================================
-- ASOCIERI FILME-GENURI
-- ==============================================

-- Citizen Kane - Clasice
INSERT INTO filme_genuri (film_id, gen_id) VALUES (1, 1);
-- The Godfather - Clasice
INSERT INTO filme_genuri (film_id, gen_id) VALUES (2, 1), (2, 4);
-- Goodfellas - Clasice
INSERT INTO filme_genuri (film_id, gen_id) VALUES (3, 1), (3, 4);
-- 12 Angry Men - Clasice, Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (4, 1), (4, 4);

-- The Dark Knight - Acțiune
INSERT INTO filme_genuri (film_id, gen_id) VALUES (5, 2), (5, 10);
-- Gladiator - Acțiune, Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (6, 2), (6, 4);
-- The Matrix - Acțiune, SF
INSERT INTO filme_genuri (film_id, gen_id) VALUES (7, 2), (7, 5);
-- Casino Royale - Acțiune
INSERT INTO filme_genuri (film_id, gen_id) VALUES (8, 2), (8, 10);

-- Fight Club - Psihologic, Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (9, 3), (9, 4);
-- Shutter Island - Psihologic, Thriller
INSERT INTO filme_genuri (film_id, gen_id) VALUES (10, 3), (10, 10);
-- Inception - Psihologic, SF
INSERT INTO filme_genuri (film_id, gen_id) VALUES (11, 3), (11, 5);
-- Black Swan - Psihologic, Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (12, 3), (12, 4);

-- Forrest Gump - Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (13, 4);
-- The Pursuit of Happyness - Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (14, 4);
-- Moonlight - Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (15, 4);
-- Requiem for a Dream - Dramă, Psihologic
INSERT INTO filme_genuri (film_id, gen_id) VALUES (16, 4), (16, 3);

-- LOTR - SF/Fantezie
INSERT INTO filme_genuri (film_id, gen_id) VALUES (17, 5), (17, 2);
-- Interstellar - SF
INSERT INTO filme_genuri (film_id, gen_id) VALUES (18, 5), (18, 4);
-- Avatar - SF
INSERT INTO filme_genuri (film_id, gen_id) VALUES (19, 5), (19, 2);
-- Blade Runner 2049 - SF
INSERT INTO filme_genuri (film_id, gen_id) VALUES (20, 5), (20, 3);

-- La La Land - Muzical, Romantic
INSERT INTO filme_genuri (film_id, gen_id) VALUES (21, 6), (21, 7);
-- Whiplash - Muzical, Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (22, 6), (22, 4);
-- The Greatest Showman - Muzical
INSERT INTO filme_genuri (film_id, gen_id) VALUES (23, 6), (23, 4);

-- The Notebook - Romantic, Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (24, 7), (24, 4);
-- 500 Days of Summer - Romantic, Comedie
INSERT INTO filme_genuri (film_id, gen_id) VALUES (25, 7), (25, 9);
-- Call Me by Your Name - Romantic, Dramă
INSERT INTO filme_genuri (film_id, gen_id) VALUES (26, 7), (26, 4);

-- ==============================================
-- UTILIZATORI DE TEST
-- ==============================================

-- Parola pentru toți: "password123" (în producție ar trebui criptată cu bcrypt/argon2)
INSERT INTO utilizatori (nume, prenume, email, parola) VALUES
('Popescu', 'Ion', 'ion.popescu@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('Ionescu', 'Maria', 'maria.ionescu@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('Dumitrescu', 'Andrei', 'andrei.dumitrescu@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('Georgescu', 'Elena', 'elena.georgescu@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('Popa', 'Mihai', 'mihai.popa@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- ==============================================
-- RECENZII EXEMPLE
-- ==============================================

-- Recenzii pentru The Dark Knight
INSERT INTO recenzii (film_id, utilizator_id, rating, titlu, continut) VALUES
(5, 1, 10.0, 'Un masterpiece absolut!', 'Heath Ledger oferă cea mai bună interpretare a lui Joker. Filmul redefinește ce înseamnă un film cu supereroi. Nolan reușește să creeze o atmosferă întunecată și realistă care te ține captivat de la început până la final.'),
(5, 2, 10.0, 'Cel mai bun film cu Batman', 'Nolan ridică filmele cu supereroi la un alt nivel. Complexitatea morală, acțiunea spectaculoasă și performanțele actoricești sunt impecabile. Un thriller psihologic deghizat în film de supereroi.'),
(5, 3, 9.0, 'Spectaculos!', 'Scenele de acțiune sunt spectaculoase, dar povestea este și ea foarte complex

ă și interesantă. Heath Ledger a meritat pe deplin Oscarul.'),
(5, 4, 10.0, 'Filmul care a schimbat totul', 'The Dark Knight a dovedit că filmele cu supereroi pot fi și opere de artă. Fiecare scenariu este perfect construit, fiecare personaj are profunzime. RIP Heath Ledger.');

-- Recenzii pentru Inception
INSERT INTO recenzii (film_id, utilizator_id, rating, titlu, continut) VALUES
(11, 1, 10.0, 'Mindbending la maxim!', 'Nolan la apogeu. Conceptul este genial executat, efectele vizuale sunt uimitoare și povestea este atât de complexă încât merită văzut de mai multe ori pentru a înțelege toate straturile.'),
(11, 2, 10.0, 'O capodoperă cinematografică', 'Inception este un film care îți provoacă mintea și inima. Soundtrack-ul lui Hans Zimmer este perfect, cinematografia este de vis, iar Leonardo DiCaprio este excepțional.'),
(11, 3, 9.0, 'Complex dar fascinant', 'Trebuie să fii foarte atent la fiecare detaliu. Este un film care te face să gândești și să discuți despre el mult după ce s-a terminat. Puțin confuz uneori, dar genial.'),
(11, 5, 10.0, 'Nolan este un geniu', 'Un film despre visuri, realitate, iubire și pierdere. Fiecare vizionare dezvăluie noi detalii. Scena finală cu totiușul este perfectă!');

-- Recenzii pentru Forrest Gump
INSERT INTO recenzii (film_id, utilizator_id, rating, titlu, continut) VALUES
(13, 2, 10.0, 'M-a făcut să plâng și să râd', 'Tom Hanks oferă una dintre cele mai bune performanțe ale carierei sale. O călătorie emoțională prin istoria Americii, văzută prin ochii unui om simplu dar cu inimă mare.'),
(13, 3, 10.0, 'Clasic absolut!', 'Un film care te inspiră să nu renunți niciodată. Povestea lui Forrest este atât de autentică și emoționantă. Merită văzut de toată familia.'),
(13, 4, 9.0, 'Emoționant și frumos', 'Life is like a box of chocolates - și acest film este dulce! O poveste despre perseverență, dragoste și loialitate.');

-- Recenzii pentru Interstellar
INSERT INTO recenzii (film_id, utilizator_id, rating, titlu, continut) VALUES
(18, 1, 10.0, 'O odisee spațială magnifică', 'Nolan combină știința cu emoția într-un mod unic. Scena cu Murph m-a făcut să plâng. Un film despre dragoste dincolo de timp și spațiu.'),
(18, 3, 9.0, 'Vizual spectaculos', 'Complexitatea științifică este fascinantă, deși poate fi puțin confuz uneori. Hans Zimmer creează un soundtrack epic care completează perfect imaginile.'),
(18, 4, 10.0, 'Masterpiece științific', 'Un film care te face să te gândești la locul nostru în univers. Emoționant, inteligent și vizual uimitor. McConaughey este excepțional.'),
(18, 5, 10.0, 'Nolan face iarăși minuni', 'O poveste despre sacrificiu, iubire și supraviețuire. Vizualurile găurii negre sunt incredibile. Un film care rămâne cu tine mult timp după.');

-- ==============================================
-- COMENTARII LA RECENZII
-- ==============================================

INSERT INTO comentarii (recenzie_id, utilizator_id, continut) VALUES
(1, 3, 'Complet de acord! Heath Ledger a fost phenomenal.'),
(1, 4, 'Cea mai bună recenzie pentru cel mai bun film!'),
(2, 1, 'Exact! Nolan este un maestru al cinematografiei.'),
(5, 2, 'Foarte bine scris! Și eu am plâns la final.'),
(5, 5, 'Soundtrack-ul este într-adevăr epic!'),
(9, 1, 'Forrest Gump este unul dintre filmele mele preferate!'),
(9, 3, 'Tom Hanks merită toate laudele!');

-- ==============================================
-- FILME FAVORITE
-- ==============================================

INSERT INTO favorite (utilizator_id, film_id) VALUES
(1, 5), (1, 11), (1, 18), (1, 13),
(2, 5), (2, 11), (2, 24), (2, 21),
(3, 11), (3, 5), (3, 7), (3, 9),
(4, 13), (4, 5), (4, 18), (4, 24),
(5, 11), (5, 18), (5, 5), (5, 22);

-- ==============================================
-- WATCHLIST
-- ==============================================

INSERT INTO watchlist (utilizator_id, film_id) VALUES
(1, 2), (1, 10), (1, 15),
(2, 9), (2, 16), (2, 20),
(3, 14), (3, 19), (3, 23),
(4, 7), (4, 12), (4, 17),
(5, 1), (5, 4), (5, 25);

-- ==============================================
-- VIEWS UTILE
-- ==============================================

-- View pentru rating mediu filme
CREATE VIEW filme_rating AS
SELECT 
    f.id,
    f.titlu,
    COUNT(r.id) as numar_recenzii,
    ROUND(AVG(r.rating), 1) as rating_mediu
FROM filme f
LEFT JOIN recenzii r ON f.id = r.film_id
GROUP BY f.id, f.titlu;

-- View pentru top filme
CREATE VIEW top_filme AS
SELECT 
    f.id,
    f.titlu,
    f.an_aparitie,
    COUNT(r.id) as numar_recenzii,
    ROUND(AVG(r.rating), 1) as rating_mediu,
    COUNT(DISTINCT fav.id) as numar_favorite
FROM filme f
LEFT JOIN recenzii r ON f.id = r.film_id
LEFT JOIN favorite fav ON f.id = fav.film_id
GROUP BY f.id, f.titlu, f.an_aparitie
HAVING numar_recenzii > 0
ORDER BY rating_mediu DESC, numar_recenzii DESC;

-- View pentru utilizatori activi
CREATE VIEW utilizatori_activi AS
SELECT 
    u.id,
    u.nume,
    u.prenume,
    u.email,
    COUNT(DISTINCT r.id) as numar_recenzii,
    COUNT(DISTINCT c.id) as numar_comentarii,
    COUNT(DISTINCT f.id) as numar_favorite
FROM utilizatori u
LEFT JOIN recenzii r ON u.id = r.utilizator_id
LEFT JOIN comentarii c ON u.id = c.utilizator_id
LEFT JOIN favorite f ON u.id = f.utilizator_id
GROUP BY u.id, u.nume, u.prenume, u.email;

-- ==============================================
-- STORED PROCEDURES
-- ==============================================

DELIMITER //

-- Procedură pentru adăugare recenzie
CREATE PROCEDURE adauga_recenzie(
    IN p_film_id INT,
    IN p_utilizator_id INT,
    IN p_rating DECIMAL(3,1),
    IN p_titlu VARCHAR(255),
    IN p_continut TEXT
)
BEGIN
    INSERT INTO recenzii (film_id, utilizator_id, rating, titlu, continut)
    VALUES (p_film_id, p_utilizator_id, p_rating, p_titlu, p_continut);
END //

-- Procedură pentru căutare filme
CREATE PROCEDURE cauta_filme(IN cuvant_cheie VARCHAR(255))
BEGIN
    SELECT 
        f.id,
        f.titlu,
        f.an_aparitie,
        f.descriere,
        ROUND(AVG(r.rating), 1) as rating_mediu,
        COUNT(r.id) as numar_recenzii
    FROM filme f
    LEFT JOIN recenzii r ON f.id = r.film_id
    WHERE f.titlu LIKE CONCAT('%', cuvant_cheie, '%')
       OR f.descriere LIKE CONCAT('%', cuvant_cheie, '%')
       OR f.regizor LIKE CONCAT('%', cuvant_cheie, '%')
    GROUP BY f.id, f.titlu, f.an_aparitie, f.descriere
    ORDER BY rating_mediu DESC;
END //

-- Procedură pentru statistici utilizator
CREATE PROCEDURE statistici_utilizator(IN p_utilizator_id INT)
BEGIN
    SELECT 
        u.nume,
        u.prenume,
        u.email,
        u.data_inregistrare,
        COUNT(DISTINCT r.id) as recenzii_scrise,
        COUNT(DISTINCT c.id) as comentarii_scrise,
        COUNT(DISTINCT f.id) as filme_favorite,
        COUNT(DISTINCT w.id) as filme_watchlist,
        ROUND(AVG(r.rating), 1) as rating_mediu_dat
    FROM utilizatori u
    LEFT JOIN recenzii r ON u.id = r.utilizator_id
    LEFT JOIN comentarii c ON u.id = c.utilizator_id
    LEFT JOIN favorite f ON u.id = f.utilizator_id
    LEFT JOIN watchlist w ON u.id = w.utilizator_id
    WHERE u.id = p_utilizator_id
    GROUP BY u.id, u.nume, u.prenume, u.email, u.data_inregistrare;
END //

DELIMITER ;

-- ==============================================
-- TRIGGERS
-- ==============================================

DELIMITER //

-- Trigger pentru actualizare automată a likes/dislikes în tabela recenzii
CREATE TRIGGER after_recenzie_rating_insert
AFTER INSERT ON recenzii_rating
FOR EACH ROW
BEGIN
    IF NEW.tip = 'like' THEN
        UPDATE recenzii SET likes = likes + 1 WHERE id = NEW.recenzie_id;
    ELSE
        UPDATE recenzii SET dislikes = dislikes + 1 WHERE id = NEW.recenzie_id;
    END IF;
END //

CREATE TRIGGER after_recenzie_rating_delete
AFTER DELETE ON recenzii_rating
FOR EACH ROW
BEGIN
    IF OLD.tip = 'like' THEN
        UPDATE recenzii SET likes = likes - 1 WHERE id = OLD.recenzie_id;
    ELSE
        UPDATE recenzii SET dislikes = dislikes - 1 WHERE id = OLD.recenzie_id;
    END IF;
END //

DELIMITER ;

-- ==============================================
-- FINALIZARE
-- ==============================================

-- Afișare rezumat
SELECT 'Baza de date CineRecenzii a fost creată cu succes!' as Status;
SELECT COUNT(*) as 'Total Genuri' FROM genuri;
SELECT COUNT(*) as 'Total Filme' FROM filme;
SELECT COUNT(*) as 'Total Utilizatori' FROM utilizatori;
SELECT COUNT(*) as 'Total Recenzii' FROM recenzii;
SELECT COUNT(*) as 'Total Comentarii' FROM comentarii;
